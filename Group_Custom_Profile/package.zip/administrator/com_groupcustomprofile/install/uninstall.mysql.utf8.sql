DROP TABLE IF EXISTS `#__groupcustomprofile_profiles`;
